Download the source code for the paper C. Xu; L. Zhang; L. Cheng; R. Koch, "Pose Estimation from Line Correspondences: A Complete Analysis and A Series of Solutions," PAMI 2016, from http://xuchi.weebly.com/rpnl.html and unpack the *content of the "code" subfolder* you will find in the archive into this folder.

