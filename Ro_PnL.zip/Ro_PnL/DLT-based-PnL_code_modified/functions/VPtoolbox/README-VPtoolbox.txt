The Vanishing Point Toolbox was downloaded from http://www-users.cs.umn.edu/~faraz/?p=research.

