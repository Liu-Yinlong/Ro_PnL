This is the source code for the paper Zhang, L., et al.: "Robust and Efficient Pose Estimation from Line Correspondences", ACCV 2012, downloaded from http://www.mip.informatik.uni-kiel.de/tiki-index.php?page=Lilian+Zhang.

