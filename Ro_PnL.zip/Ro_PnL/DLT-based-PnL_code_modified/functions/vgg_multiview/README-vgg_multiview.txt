Functions in this directory are part of the "MATLAB Functions for Multiple View Geometry" available at http://www.robots.ox.ac.uk/~vgg/hzbook/code/.
