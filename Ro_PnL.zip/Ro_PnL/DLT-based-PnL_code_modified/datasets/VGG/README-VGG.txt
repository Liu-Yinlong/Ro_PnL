Data in this directory and its subdirectories are part of the "VGG Multiview Dataset" available at http://www.robots.ox.ac.uk/~vgg/data/data-mview.html.
