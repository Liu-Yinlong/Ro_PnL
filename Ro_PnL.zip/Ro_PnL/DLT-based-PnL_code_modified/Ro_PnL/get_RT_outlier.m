function [R_opt,t_opt,tim]=get_RT_outlier(data_2d_v,data_2d_c,data_3d_v,data_3d_c,epsilon)
%GET_RT_OUTLIER �˴���ʾ�йش˺�����ժҪ
%   �˴���ʾ��ϸ˵��
data_2d_N_non=cross(data_2d_v,data_2d_c);
data_2d_N=data_2d_N_non./vecnorm(data_2d_N_non);
tic
[R_opt]=RotationSearch(data_3d_v,data_2d_N,epsilon);
index_inlier=dot(R_opt*data_3d_v,data_2d_N)<=epsilon;
[t_opt] = get_trans_outlier(data_2d_N(:,index_inlier),data_3d_c(:,index_inlier),R_opt);
tim=toc;
end

