function [Q_upper,Q_lower]= get_bound(Point_M,Point_N,B,epsilon)

M=size(Point_M,2);
B_c=0.5*(B(1:3)+B(4:6));
R_c=rotationVectorToMatrix(B_c);
delta_B=0.5*(norm(B(4:6)-B(1:3)));

X=R_c*Point_M;
Y=Point_N;
Q_lower=0;
Q_upper=0;

% e=X'*Y;
% tem=abs(acos(e)-pi/2);
% flag_lower=tem<=epsilon;
% flag_upper=tem<=epsilon+delta_B;
% Q_lower=sum(dmperm(flag_lower)>0);
% Q_upper=sum(dmperm(flag_upper)>0);
for i=1:M
    e=X(:,i)'*Y(:,i);
    tem=abs(acos(e)-pi/2);
    Q_lower=Q_lower+double(sum(tem<=epsilon)>0);
    Q_upper=Q_upper+double(sum(tem<=(epsilon+delta_B))>0);
end












end